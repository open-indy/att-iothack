/* MobileConnect localhost:3003 */

module.exports = {
		name: 'development',
		port: 3003,
		publicDir: '/public/'
};
