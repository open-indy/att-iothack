/* MobileConnect localhost:3003 */

module.exports = {
		name: 'default',
		port: 3003,
		publicDir: '/public/'
};
